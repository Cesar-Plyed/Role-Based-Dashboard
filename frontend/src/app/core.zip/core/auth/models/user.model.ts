export type UserRole = 'ADMIN' | 'USER' | 'SUPERVISOR' | 'PROVEEDOR';

export interface User {
  id: string;
  nombre: string;
  email: string;
  role: UserRole;
}

export interface AuthResponse {
  token: string;
  refreshToken?: string;
  user: User;
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface RegisterRequest {
  username: string;
  password: string;
  role?: UserRole;
}
